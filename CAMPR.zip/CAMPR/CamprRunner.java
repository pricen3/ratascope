import CAMPRRUN.CAMPR;
public class CamprRunner {

   public static void main(String[] args) throws Exception{
      CAMPR.main(args);
   }

}
